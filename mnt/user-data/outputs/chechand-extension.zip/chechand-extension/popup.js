const DEFAULTS = {
  enabled: true,
  position: "both",
  showGold: true,
  showCurrency: true,
  showCrypto: true,
  showMovers: true,
  showAds: true,
};

const SITE_URL = "https://example.com/"; // بعد از مشخص‌شدن دامنه‌ی نهایی سایت، این را عوض کنید

const els = {
  enabled: document.getElementById("pp-enabled"),
  position: document.getElementById("pp-position"),
  gold: document.getElementById("pp-gold"),
  currency: document.getElementById("pp-currency"),
  crypto: document.getElementById("pp-crypto"),
  movers: document.getElementById("pp-movers"),
  ads: document.getElementById("pp-ads"),
};

document.getElementById("pp-site-link").href = SITE_URL;

function load() {
  chrome.storage.sync.get(DEFAULTS, (v) => {
    els.enabled.checked = v.enabled;
    els.position.value = v.position;
    els.gold.checked = v.showGold;
    els.currency.checked = v.showCurrency;
    els.crypto.checked = v.showCrypto;
    els.movers.checked = v.showMovers;
    els.ads.checked = v.showAds;
  });
}

function currentPrefs() {
  return {
    enabled: els.enabled.checked,
    position: els.position.value,
    showGold: els.gold.checked,
    showCurrency: els.currency.checked,
    showCrypto: els.crypto.checked,
    showMovers: els.movers.checked,
    showAds: els.ads.checked,
  };
}

function save() {
  chrome.storage.sync.set(currentPrefs());
}

Object.values(els).forEach((el) => el.addEventListener("change", save));
load();

// دکمه‌ی «نمایش روی گوگل» — تنظیمات را ذخیره می‌کند و فوراً به تب باز
// گوگل خبر می‌دهد تا بدون نیاز به رفرش دستی به‌روز شود؛ اگر تب گوگلی
// باز نبود، یکی باز می‌کند.
document.getElementById("pp-show-btn").addEventListener("click", () => {
  const prefs = currentPrefs();
  const btn = document.getElementById("pp-show-btn");
  const status = document.getElementById("pp-status");

  chrome.storage.sync.set(prefs, () => {
    chrome.tabs.query({ url: "https://www.google.com/*" }, (tabs) => {
      if (tabs.length) {
        tabs.forEach((tab) => {
          chrome.tabs.sendMessage(tab.id, { type: "cc-prefs-updated", prefs }, () => {
            if (chrome.runtime.lastError) { /* تب هنوز اسکریپت را لود نکرده — مشکلی نیست */ }
          });
          chrome.tabs.update(tab.id, { active: true });
        });
      } else {
        chrome.tabs.create({ url: "https://www.google.com/" });
      }
      btn.textContent = "اعمال شد ✓";
      btn.classList.add("pp-show-done");
      status.textContent = "روی تب گوگل اعمال شد — اگر نمی‌بینید، مطمئن شوید در صفحه‌ی اصلی گوگل هستید (نه نتایج جستجو).";
      setTimeout(() => {
        btn.textContent = "نمایش روی گوگل ›";
        btn.classList.remove("pp-show-done");
      }, 2500);
    });
  });
});
