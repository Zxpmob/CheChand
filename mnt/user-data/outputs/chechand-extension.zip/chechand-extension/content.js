/**
 * content.js — نوار قیمت «چی چند» کنار جعبه‌ی جستجوی گوگل
 * -------------------------------------------------------------
 * فقط روی صفحه‌ی اصلی گوگل (نه نتایج جستجو) نشان داده می‌شود، به‌صورت
 * یک نوار باریک کنار جعبه‌ی جستجو؛ با کلیک روی نوار باز می‌شود و لیست
 * آیتم‌های انتخاب‌شده (با تیک کنار هرکدام) را نشان می‌دهد.
 */

const CC_DEFAULTS = {
  enabled: true,
  position: "both", // "both" | "left" | "right" | "none"
  showGold: true,
  showCurrency: true,
  showCrypto: true,
  showMovers: true,
  showAds: true,
};

const CC_SITE_URL = "https://example.com/"; // بعد از مشخص‌شدن دامنه‌ی نهایی سایت، این را عوض کنید

// آیتم‌های ثابتی که این ابزار سبک کناری پشتیبانی می‌کند؛ تیک هرکدام را
// می‌شود جدا از تنظیمات popup، مستقیم روی خودِ نوار زد.
const CC_ITEM_DEFS = [
  { id: "gold-ounce", cat: "gold", name: "انس جهانی طلا" },
  { id: "gold-18", cat: "gold", name: "طلای ۱۸ عیار" },
  { id: "usd", cat: "currency", name: "دلار آمریکا" },
  { id: "eur", cat: "currency", name: "یورو" },
  { id: "try", cat: "currency", name: "لیر ترکیه" },
  { id: "aed", cat: "currency", name: "درهم امارات" },
  { id: "crypto-bitcoin", cat: "crypto", name: "بیت‌کوین" },
  { id: "crypto-ethereum", cat: "crypto", name: "اتریوم" },
  { id: "crypto-tether", cat: "crypto", name: "تتر" },
];

function ccIsHomepage() {
  // فقط صفحه‌ی اصلیِ خالیِ گوگل — نه نتایج جستجو (/search)، نه صفحات دیگر
  const p = location.pathname.replace(/\/+$/, "");
  const hasQuery = new URLSearchParams(location.search).get("q");
  return (p === "" || p === "/webhp") && !hasQuery;
}

function ccGetPrefs() {
  return new Promise((resolve) => {
    chrome.storage.sync.get(CC_DEFAULTS, (base) => {
      chrome.storage.sync.get({ itemToggles: {} }, (extra) => {
        resolve({ ...base, itemToggles: extra.itemToggles });
      });
    });
  });
}

function ccSetItemToggle(id, on) {
  chrome.storage.sync.get({ itemToggles: {} }, (v) => {
    const t = v.itemToggles || {};
    t[id] = on;
    chrome.storage.sync.set({ itemToggles: t });
  });
}

async function ccFetchJson(url) {
  try {
    const res = await fetch(url, { cache: "no-store" });
    if (!res.ok) return null;
    return await res.json();
  } catch (e) {
    return null;
  }
}

async function ccFetchPrices() {
  const [gold, fiat, coins] = await Promise.all([
    ccFetchJson("https://raw.githubusercontent.com/HosseinOdd/Navasan-API/main/data/gold.json"),
    ccFetchJson("https://raw.githubusercontent.com/HosseinOdd/Navasan-API/main/data/fiat.json"),
    ccFetchJson("https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=20&page=1&price_change_percentage=24h"),
  ]);

  const values = {}; // id -> {price, changePercent, unit}
  if (gold && gold["18ayar"] && typeof gold["18ayar"].value === "number") {
    values["gold-18"] = { price: gold["18ayar"].value, unit: "تومان" };
  }
  if (gold && gold["usd_xau"] && gold["usd_xau"].value !== undefined) {
    values["gold-ounce"] = { price: Number(gold["usd_xau"].value), unit: "دلار" };
  }
  if (fiat) {
    ["usd", "eur", "try", "aed"].forEach((key) => {
      const row = fiat[key];
      if (row && typeof row.value === "number") values[key] = { price: row.value, unit: "تومان" };
    });
  }
  let movers = [];
  if (Array.isArray(coins)) {
    coins.forEach((c) => {
      values["crypto-" + c.id] = {
        price: c.current_price,
        unit: "دلار",
        changePercent: c.price_change_percentage_24h,
      };
    });
    movers = coins
      .filter((c) => typeof c.price_change_percentage_24h === "number")
      .slice()
      .sort((a, b) => Math.abs(b.price_change_percentage_24h) - Math.abs(a.price_change_percentage_24h))
      .slice(0, 3)
      .map((c) => ({ name: (c.symbol || c.name).toUpperCase(), price: c.current_price, changePercent: c.price_change_percentage_24h, unit: "دلار" }));
  }
  return { values, movers };
}

function ccFormatPrice(n) {
  if (typeof n !== "number" || Number.isNaN(n)) return "—";
  return n.toLocaleString("en-US", { maximumFractionDigits: n < 10 ? 4 : 0 });
}

function ccRowHTML(name, id, info, checked) {
  const chg = info ? info.changePercent : null;
  const hasChg = typeof chg === "number" && !Number.isNaN(chg);
  const cls = hasChg ? (chg > 0 ? "cc-up" : chg < 0 ? "cc-down" : "") : "";
  const chgTxt = hasChg ? `${chg > 0 ? "▲" : chg < 0 ? "▼" : "•"} ${Math.abs(chg).toFixed(1)}%` : "";
  const checkboxHtml = id ? `<input type="checkbox" data-item="${id}" ${checked ? "checked" : ""}>` : "";
  return `
    <div class="cc-row">
      <label class="cc-row-check">
        ${checkboxHtml}
        <span class="cc-row-name">${name}</span>
      </label>
      <span class="cc-row-right">
        <span class="cc-row-price">${info ? ccFormatPrice(info.price) : "—"} <small>${info ? info.unit : ""}</small></span>
        ${hasChg ? `<span class="cc-row-chg ${cls}">${chgTxt}</span>` : ""}
      </span>
    </div>`;
}

function ccAdSlot(slotId) {
  return `<div class="cc-ad-slot" id="${slotId}"><span class="cc-ad-label">فضای تبلیغاتی</span></div>`;
}

function ccPanelHTML(side, data, prefs) {
  const toggles = prefs.itemToggles || {};
  const isOn = (id) => toggles[id] !== false; // پیش‌فرض: روشن

  const catLabel = { gold: "طلا", currency: "ارز", crypto: "ارز دیجیتال" };
  const catFlags = { gold: prefs.showGold, currency: prefs.showCurrency, crypto: prefs.showCrypto };

  let rows = "";
  ["gold", "currency", "crypto"].forEach((cat) => {
    if (!catFlags[cat]) return;
    const catItems = CC_ITEM_DEFS.filter((it) => it.cat === cat && isOn(it.id));
    if (!catItems.length) return;
    rows += `<div class="cc-section-title">${catLabel[cat]}</div>`;
    rows += catItems.map((it) => ccRowHTML(it.name, it.id, data.values[it.id], true)).join("");
  });

  let moversHTML = "";
  if (prefs.showMovers && data.movers.length) {
    moversHTML = `<div class="cc-section-title">پرتغییرترین‌های امروز</div>` +
      data.movers.map((m) => ccRowHTML(m.name, null, m, true)).join("");
  }

  return `
    <div class="cc-tab" id="cc-tab-${side}" title="چی چند">
      <img src="${chrome.runtime.getURL("icons/icon-32.png")}" alt="">
    </div>
    <div class="cc-panel" id="cc-panel-${side}" hidden>
      <div class="cc-header">
        <a href="${CC_SITE_URL}" target="_blank" rel="noopener" class="cc-brand">
          <img src="${chrome.runtime.getURL("icons/icon-32.png")}" alt="">
          <span>چی چند</span>
        </a>
        <button class="cc-close" data-side="${side}" title="بستن">✕</button>
      </div>
      <div class="cc-body">
        ${rows || '<div class="cc-empty">هیچ بخشی فعال نیست — از تنظیمات افزونه، بخش موردنظر را روشن کنید.</div>'}
        ${moversHTML}
        ${prefs.showAds ? ccAdSlot("cc-ad-" + side + "-1") : ""}
      </div>
      <a href="${CC_SITE_URL}" target="_blank" rel="noopener" class="cc-footer-link">مشاهده‌ی کامل قیمت‌ها ›</a>
    </div>`;
}

function ccWireSide(root, side) {
  const tab = root.querySelector("#cc-tab-" + side);
  const panel = root.querySelector("#cc-panel-" + side);
  if (!tab || !panel) return;

  tab.addEventListener("click", () => {
    const isHidden = panel.hasAttribute("hidden");
    root.querySelectorAll(".cc-panel").forEach((p) => p.setAttribute("hidden", ""));
    if (isHidden) panel.removeAttribute("hidden");
  });
  panel.querySelector(".cc-close")?.addEventListener("click", () => panel.setAttribute("hidden", ""));

  panel.querySelectorAll('input[type="checkbox"][data-item]').forEach((cb) => {
    cb.addEventListener("change", () => {
      ccSetItemToggle(cb.dataset.item, cb.checked);
      const row = cb.closest(".cc-row");
      if (!cb.checked && row) row.style.display = "none";
    });
  });
}

function ccPositionNearSearchBox(root) {
  const input = document.querySelector('input[name="q"], textarea[name="q"]');
  if (!input) return;
  const rect = input.getBoundingClientRect();
  const top = Math.max(80, rect.top + window.scrollY - 20);
  root.querySelectorAll(".cc-side").forEach((el) => {
    el.style.top = top + "px";
  });
}

async function ccInit() {
  if (!ccIsHomepage()) return; // فقط صفحه‌ی اصلی، نه نتایج جستجو
  const prefs = await ccGetPrefs();
  if (!prefs.enabled || prefs.position === "none") return;

  const data = await ccFetchPrices();

  const wrap = document.createElement("div");
  wrap.id = "cc-widget-root";
  let html = "";
  if (prefs.position === "both" || prefs.position === "right") {
    html += `<div class="cc-side cc-side-right">${ccPanelHTML("right", data, prefs)}</div>`;
  }
  if (prefs.position === "both" || prefs.position === "left") {
    html += `<div class="cc-side cc-side-left">${ccPanelHTML("left", data, prefs)}</div>`;
  }
  wrap.innerHTML = html;
  document.documentElement.appendChild(wrap);

  if (prefs.position === "both" || prefs.position === "right") ccWireSide(wrap, "right");
  if (prefs.position === "both" || prefs.position === "left") ccWireSide(wrap, "left");

  ccPositionNearSearchBox(wrap);
  window.addEventListener("resize", () => ccPositionNearSearchBox(wrap));
}

function ccRemoveWidget() {
  const old = document.getElementById("cc-widget-root");
  if (old) old.remove();
}

if (document.readyState === "complete" || document.readyState === "interactive") {
  ccInit();
} else {
  document.addEventListener("DOMContentLoaded", ccInit);
}

// وقتی تنظیمات از popup عوض می‌شود، فوراً پنل را دوباره می‌سازیم —
// دیگر نیازی به رفرش دستی صفحه‌ی گوگل نیست
chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === "cc-prefs-updated") {
    ccRemoveWidget();
    ccInit();
  }
});
